package uk.ac.aston.jpd.team11.groupwork.entities;

public class NonDeveloper extends Person {

	public NonDeveloper() {

	}

	public void tick() {

	}

}
