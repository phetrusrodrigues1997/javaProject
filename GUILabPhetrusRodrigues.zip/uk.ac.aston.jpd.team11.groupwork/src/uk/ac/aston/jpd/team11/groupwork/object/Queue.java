package uk.ac.aston.jpd.team11.groupwork.object;

public class Queue {
	private float averageWaitingTime;
	private int currentSize;
	
	
	public float getAverageWaitingTime() {
		return averageWaitingTime;
	}
	public int getCurrentSize() {
		return currentSize;
	}
	
	
}
