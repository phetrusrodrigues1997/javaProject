package uk.ac.aston.jpd.team11.groupwork.object;

import uk.ac.aston.jpd.team11.groupwork.entities.Person;

public class Floor extends Building{
	private int floorNumber;

	
	public int getFloorNumber() {
		return floorNumber;
	}
	

	//public Person departures() {
		
	//}
}
