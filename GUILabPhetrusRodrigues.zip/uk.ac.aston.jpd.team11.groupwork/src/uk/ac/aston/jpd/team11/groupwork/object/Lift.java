package uk.ac.aston.jpd.team11.groupwork.object;

import uk.ac.aston.jpd.team11.groupwork.entities.Person;

public class Lift {
	private String direction;
	private Person currentOccupation;
	private int capacity;
	
	public String getDirection() {
		return direction;
	}
	
	public void setRandomCapacity() {
		
	}
	
	public Person getCurrentOccupation() {
		return currentOccupation;
	}

}
