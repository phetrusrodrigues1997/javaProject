package uk.ac.aston.jpd.team11.groupwork.tick;

public abstract class Event implements TickAccessor{
	private int tick;
}
