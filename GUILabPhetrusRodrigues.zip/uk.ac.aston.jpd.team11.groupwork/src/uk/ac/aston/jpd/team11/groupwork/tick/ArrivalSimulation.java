package uk.ac.aston.jpd.team11.groupwork.tick;

public class ArrivalSimulation {

}
