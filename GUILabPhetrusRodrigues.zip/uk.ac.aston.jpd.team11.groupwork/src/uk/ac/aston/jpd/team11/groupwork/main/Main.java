package uk.ac.aston.jpd.team11.groupwork.main;

import java.util.Random;
import java.util.Scanner;

public class Main {
	public static int numOfEmployees;
	public static int numOfDevelopers;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rnd = new Random();
		Scanner scanner = new Scanner (System.in);
		System.out.println("Please enter the number of employees for the simulation:");
		numOfEmployees = scanner.nextInt();
		System.out.println("--------------------------------------------------------");
		System.out.println("Please enter the number of developers for the simulation:");
		numOfDevelopers = scanner.nextInt();
		//scanner.close();
	}

}
