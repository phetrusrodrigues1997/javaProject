package uk.ac.aston.jpd.team11.groupwork.entities;

public class Developer extends Person {

	public void tick() {

	}

}
