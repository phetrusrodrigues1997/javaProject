package uk.ac.aston.jpd.team11.groupwork.object;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import uk.ac.aston.jpd.team11.groupwork.entities.Client;
import uk.ac.aston.jpd.team11.groupwork.entities.Developer;
import uk.ac.aston.jpd.team11.groupwork.entities.Maintenance;
import uk.ac.aston.jpd.team11.groupwork.entities.NonDeveloper;
import uk.ac.aston.jpd.team11.groupwork.entities.Person;
import uk.ac.aston.jpd.team11.groupwork.main.Main;

public class Building {
	private Lift lift = new Lift();
	protected Floor[] floors = new Floor[6];
	private Queue<Person> queue = new LinkedList<>();
	private List<Person> clients = new ArrayList<Person>();
	private List<Person> maint = new ArrayList<Person>();
	private Developer[] devs = new Developer[Main.numOfEmployees];
	private NonDeveloper[] nonDevs = new NonDeveloper[Main.numOfDevelopers];

	// public void addPeople(Person people) {
	// this.people.add(people);
	// }

	public void tick() {
		for (Developer d : devs) {
			d.tick();
		}

		for (NonDeveloper nd : nonDevs) {
			nd.tick();
		}
	}

	public void arrive(Person p) {
		queue.add(p);
		if (p instanceof Client) {
			clients.add(p);
		} else if (p instanceof Maintenance) {
			maint.add(p);
		}
	}

	public void arrival(Person p) {
		queue.add(p);
	}

	public Queue<Person> getQueue() {
		return queue;
	}

	public List<Person> getClient() {
		return clients;
	}

	public List<Person> getMaintenance() {
		return maint;
	}

	public Lift getLift() {
		return lift;
	}

}
