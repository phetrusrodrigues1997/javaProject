package uk.ac.aston.jpd.team11.groupwork.object;

public class Button extends Floor{
	private int direction;

	public int getDirection() {
		return direction;
	}
}
