package uk.ac.aston.jpd.team11.groupwork.tick;

import java.util.Random;

import uk.ac.aston.jpd.team11.groupwork.object.Building;

public class Simulation {
	private int tick = 0;
	
	private float probability;
	private Building building;
	
	public Simulation (Random rnd) {
		this.building = new Building();
	}
	
	public void tick() {
		tick++;
	}
	
	public int getTick() {
		return tick;
	}
	
	public float getProbability() {
		return probability;
	}
	
	public Building getBuilding() {
		return building;
	}

}
