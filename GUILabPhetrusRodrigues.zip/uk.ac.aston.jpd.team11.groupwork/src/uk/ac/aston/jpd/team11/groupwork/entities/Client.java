package uk.ac.aston.jpd.team11.groupwork.entities;

public class Client extends Person {
	private int waitingTime;
	private String patience;
	private boolean isImpatient;

	public Client() {
		isImpatient = false;
	}

	public boolean checkPatience() {
		for (int i = 0; i < 600; i = i + 1) {
			if (waitingTime == 450) {
				patience = "Impatient";
				isImpatient = true;
			}
		}
		return isImpatient;
	}
}
