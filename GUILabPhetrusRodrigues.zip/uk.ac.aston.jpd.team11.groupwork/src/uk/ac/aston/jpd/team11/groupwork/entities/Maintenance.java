package uk.ac.aston.jpd.team11.groupwork.entities;

public class Maintenance extends Person{

}
