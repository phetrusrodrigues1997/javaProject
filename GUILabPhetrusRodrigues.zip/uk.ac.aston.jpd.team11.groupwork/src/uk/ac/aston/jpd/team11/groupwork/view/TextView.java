package uk.ac.aston.jpd.team11.groupwork.view;

import uk.ac.aston.jpd.team11.groupwork.entities.Client;
import uk.ac.aston.jpd.team11.groupwork.entities.Person;
import uk.ac.aston.jpd.team11.groupwork.object.Lift;
import uk.ac.aston.jpd.team11.groupwork.tick.Simulation;

public class TextView {
	public void show(Simulation s) {
		System.out.println("------------");
		System.out.println("Tick: " + s.getTick());
		System.out.println();
		if(s.getBuilding().getQueue().isEmpty()) {
			System.out.println("Queue is Empty!");
		} else {
			System.out.println("Queue: ");
			for(Person p : s.getBuilding().getQueue()) {
				System.out.println(String.format(" - %s" , p));
			}
			System.out.println();
		}
		System.out.println("Lift:");
		Lift currentLiftStatus = new Lift();
		Person occupying = currentLiftStatus.getCurrentOccupation();
		if(occupying == null) {
			System.out.println(" - waiting");
		} else {
			System.out.println(String.format(" - occupied by %s ", occupying));
		}
		System.out.println();
		Client client = new Client() ;
		if (client.checkPatience()) {
			System.out.println("I have waited for too long, i am now IMPATIENT");
		}
	}
}
