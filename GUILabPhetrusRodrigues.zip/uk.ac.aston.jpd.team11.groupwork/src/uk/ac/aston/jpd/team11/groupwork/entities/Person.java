package uk.ac.aston.jpd.team11.groupwork.entities;

import uk.ac.aston.jpd.team11.groupwork.object.Floor;

public abstract class Person {
	protected int uniqueld;
	protected int currentFloor;

	public Person() {

	}
	// public Floor floorDestination(int floor) {

	// }

	public int getUniqueld() {
		return uniqueld;
	}

	public int getCurrentFloor() {
		return currentFloor;
	}

}
